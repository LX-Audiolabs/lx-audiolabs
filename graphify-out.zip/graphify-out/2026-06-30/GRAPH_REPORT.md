# Graph Report - .  (2026-06-30)

## Corpus Check
- cluster-only mode — file stats not available

## Summary
- 587 nodes · 1240 edges · 23 communities (16 shown, 7 thin omitted)
- Extraction: 98% EXTRACTED · 2% INFERRED · 0% AMBIGUOUS · INFERRED: 27 edges (avg confidence: 0.8)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `47fbea27`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- [[_COMMUNITY_Lucent Relay Editor|Lucent Relay Editor]]
- [[_COMMUNITY_UI Widgets|UI Widgets]]
- [[_COMMUNITY_Aether Editor|Aether Editor]]
- [[_COMMUNITY_Aurum Editor & Analysis|Aurum Editor & Analysis]]
- [[_COMMUNITY_Lucent Core|Lucent Core]]
- [[_COMMUNITY_Canvas Visualizers|Canvas Visualizers]]
- [[_COMMUNITY_Shared Memory Hub|Shared Memory Hub]]
- [[_COMMUNITY_Aurum Core|Aurum Core]]
- [[_COMMUNITY_Aether Core|Aether Core]]
- [[_COMMUNITY_Lucent Editor|Lucent Editor]]
- [[_COMMUNITY_Vault & Config|Vault & Config]]
- [[_COMMUNITY_Filter Design|Filter Design]]
- [[_COMMUNITY_FFT Analysis|FFT Analysis]]
- [[_COMMUNITY_Metering & Dynamics|Metering & Dynamics]]
- [[_COMMUNITY_Lucent UI State|Lucent UI State]]
- [[_COMMUNITY_DSP Constructors|DSP Constructors]]
- [[_COMMUNITY_Biquad Filter|Biquad Filter]]
- [[_COMMUNITY_UI Panels|UI Panels]]
- [[_COMMUNITY_Meter Reset Ops|Meter Reset Ops]]
- [[_COMMUNITY_Peak Meter|Peak Meter]]
- [[_COMMUNITY_RMS Meter|RMS Meter]]
- [[_COMMUNITY_Compressor|Compressor]]
- [[_COMMUNITY_Community 22|Community 22]]

## God Nodes (most connected - your core abstractions)
1. `AetherEditor` - 35 edges
2. `LucentRelay` - 24 edges
3. `SharedState` - 22 edges
4. `Biquad` - 22 edges
5. `Lucent` - 21 edges
6. `RelayHub` - 21 edges
7. `AetherParams` - 20 edges
8. `AurumEditor` - 20 edges
9. `Aurum` - 20 edges
10. `LucentEditor` - 17 edges

## Surprising Connections (you probably didn't know these)
- `section_header()` --calls--> `bold_font()`  [INFERRED]
  aether/src/editor.rs → shared-ui/src/widgets.rs
- `AetherEditor` --references--> `SharedState`  [EXTRACTED]
  aether/src/editor.rs → shared-analysis/src/lib.rs
- `AetherParams` --references--> `SharedState`  [EXTRACTED]
  aether/src/lib.rs → shared-analysis/src/lib.rs
- `Aether` --references--> `Biquad`  [EXTRACTED]
  aether/src/lib.rs → shared-dsp/src/lib.rs
- `set_band()` --references--> `Biquad`  [EXTRACTED]
  aether/src/lib.rs → shared-dsp/src/lib.rs

## Import Cycles
- 1-file cycle: `shared-ui/src/canvas.rs -> shared-ui/src/canvas.rs`

## Communities (23 total, 7 thin omitted)

### Community 0 - "Lucent Relay Editor"
Cohesion: 0.05
Nodes (38): RelayMsg, RelayUi, Arc, Element, IcedPlugin, Message, ParamCache, PluginContext (+30 more)

### Community 1 - "UI Widgets"
Cohesion: 0.10
Nodes (50): Action, Event, Font, Interaction, Point, RangeInclusive, at_block(), auto_loud_button() (+42 more)

### Community 2 - "Aether Editor"
Cohesion: 0.10
Nodes (32): AetherEditor, AetherMsg, AetherProfile, angle_from_ui(), default_presets(), eq_field_id(), harman_flat_profile(), parse_aether_preset() (+24 more)

### Community 3 - "Aurum Editor & Analysis"
Cohesion: 0.08
Nodes (33): AtomicF32, AtomicI32, AtomicU8, AtomicUsize, AurumEditor, AurumMsg, band_col(), Arc (+25 more)

### Community 4 - "Lucent Core"
Cohesion: 0.08
Nodes (28): gain_to_db(), Lucent, LucentParams, LucentState, MaskingAnalyzer, PeakTracker, resonance_hub(), Arc (+20 more)

### Community 5 - "Canvas Visualizers"
Cohesion: 0.14
Nodes (29): Color, Length, balance_correlation_block(), BalanceCanvas, CorrelationCanvas, EqOverlay, GoniometerCanvas, output_level_block() (+21 more)

### Community 6 - "Shared Memory Hub"
Cohesion: 0.11
Nodes (16): AtomicU32, AtomicU64, Send, ConsumerSlot, display_name(), HubShared, PublisherSlot, RelayHub (+8 more)

### Community 7 - "Aurum Core"
Cohesion: 0.08
Nodes (16): Aurum, Arc, AtomicBool, AudioBuffer, Box, Drop, Editor, EventList (+8 more)

### Community 8 - "Aether Core"
Cohesion: 0.11
Nodes (18): Aether, AutoEqFilter, AutoEqProfile, parse_autoeq(), parses_autoeq(), Arc, AudioBuffer, Box (+10 more)

### Community 9 - "Lucent Editor"
Cohesion: 0.14
Nodes (16): LucentEditor, LucentMsg, panel_bg(), Arc, Element, IcedPlugin, Message, Option (+8 more)

### Community 10 - "Vault & Config"
Cohesion: 0.18
Nodes (22): Error, HashMap, export_preset_to_markdown(), format_pan_str(), get_plugin_dir(), list_custom_presets(), load_config(), parse_frontmatter() (+14 more)

### Community 11 - "Filter Design"
Cohesion: 0.12
Nodes (6): BandLimiter, Compressor, LR2Crossover, MsBandLimiter, Default, TwoBandCompressor

### Community 12 - "FFT Analysis"
Cohesion: 0.16
Nodes (7): RealFftPlanner, Complex, Default, Self, Vec, SnapFFT, SnapMode

### Community 13 - "Metering & Dynamics"
Cohesion: 0.24
Nodes (6): LucentUiState, RelayData, Default, Self, String, Vec

### Community 16 - "Biquad Filter"
Cohesion: 0.20
Nodes (5): EbuR128, AutoLoudMeter, HarmonicsMode, MasteringClipper, MasteringSaturator

### Community 17 - "UI Panels"
Cohesion: 0.27
Nodes (10): Item, Iterator, ai_preset_panel(), preset_list_item(), Element, Fn, Message, Option (+2 more)

## Knowledge Gaps
- **7 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `SharedState` connect `Aurum Editor & Analysis` to `Lucent Relay Editor`, `Aether Editor`, `Lucent Core`, `Aurum Core`, `Aether Core`, `Lucent Editor`?**
  _High betweenness centrality (0.390) - this node is a cross-community bridge._
- **Why does `Biquad` connect `DSP Constructors` to `Aurum Core`, `Aether Core`, `Filter Design`, `Lucent UI State`, `Biquad Filter`, `Meter Reset Ops`, `Compressor`, `Community 22`?**
  _High betweenness centrality (0.163) - this node is a cross-community bridge._
- **Why does `Aurum` connect `Aurum Core` to `Aurum Editor & Analysis`, `Filter Design`, `DSP Constructors`, `Compressor`, `Community 22`?**
  _High betweenness centrality (0.142) - this node is a cross-community bridge._
- **Should `Lucent Relay Editor` be split into smaller, more focused modules?**
  _Cohesion score 0.05245901639344262 - nodes in this community are weakly interconnected._
- **Should `UI Widgets` be split into smaller, more focused modules?**
  _Cohesion score 0.1016949152542373 - nodes in this community are weakly interconnected._
- **Should `Aether Editor` be split into smaller, more focused modules?**
  _Cohesion score 0.10163339382940109 - nodes in this community are weakly interconnected._
- **Should `Aurum Editor & Analysis` be split into smaller, more focused modules?**
  _Cohesion score 0.0824829931972789 - nodes in this community are weakly interconnected._