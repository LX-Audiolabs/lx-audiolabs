import json
from pathlib import Path

# For incremental mode with a small doc corpus, use a simple pass:
# just index markdown headings/sections as nodes, no LLM needed.

detect = json.loads(Path('graphify-out/.graphify_detect.json').read_text(encoding='utf-8'))
all_files = [f for cat in ('document', 'paper', 'image') for f in detect['files'].get(cat, [])]

nodes = []
edges = []
hyperedges = []

for fpath in all_files:
    try:
        content = Path(fpath).read_text(encoding='utf-8', errors='ignore')
        lines = content.split('\n')

        # Extract headings as section nodes
        for i, line in enumerate(lines):
            if line.startswith('#'):
                level = len(line) - len(line.lstrip('#'))
                title = line.lstrip('# ').strip()
                if title:
                    node_id = f"doc_{Path(fpath).stem}_{i}"
                    nodes.append({
                        'id': node_id,
                        'label': title[:50],
                        'type': 'section',
                        'source_file': fpath,
                        'source_location': f'{fpath}:{i+1}',
                        'confidence': 0.95,
                        'evidence': 'EXTRACTED',
                    })
    except Exception as e:
        pass

result = {
    'nodes': nodes,
    'edges': edges,
    'hyperedges': hyperedges,
    'input_tokens': 0,
    'output_tokens': 0,
}

Path('graphify-out/.graphify_semantic.json').write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding='utf-8')
print(f'Semantic: {len(nodes)} nodes from {len(all_files)} files')
