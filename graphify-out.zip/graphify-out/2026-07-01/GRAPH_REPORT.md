# Graph Report - lx-audiolabs-dev  (2026-07-01)

## Corpus Check
- 41 files · ~60,815 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 792 nodes · 1549 edges · 39 communities (32 shown, 7 thin omitted)
- Extraction: 98% EXTRACTED · 2% INFERRED · 0% AMBIGUOUS · INFERRED: 34 edges (avg confidence: 0.8)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `8faad436`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- [[_COMMUNITY_Lucent Relay Editor|Lucent Relay Editor]]
- [[_COMMUNITY_UI Widgets|UI Widgets]]
- [[_COMMUNITY_Aether Editor|Aether Editor]]
- [[_COMMUNITY_Aurum Editor & Analysis|Aurum Editor & Analysis]]
- [[_COMMUNITY_Lucent Core|Lucent Core]]
- [[_COMMUNITY_Canvas Visualizers|Canvas Visualizers]]
- [[_COMMUNITY_Shared Memory Hub|Shared Memory Hub]]
- [[_COMMUNITY_Aurum Core|Aurum Core]]
- [[_COMMUNITY_Aether Core|Aether Core]]
- [[_COMMUNITY_Lucent Editor|Lucent Editor]]
- [[_COMMUNITY_Vault & Config|Vault & Config]]
- [[_COMMUNITY_Filter Design|Filter Design]]
- [[_COMMUNITY_FFT Analysis|FFT Analysis]]
- [[_COMMUNITY_Metering & Dynamics|Metering & Dynamics]]
- [[_COMMUNITY_Lucent UI State|Lucent UI State]]
- [[_COMMUNITY_DSP Constructors|DSP Constructors]]
- [[_COMMUNITY_Biquad Filter|Biquad Filter]]
- [[_COMMUNITY_UI Panels|UI Panels]]
- [[_COMMUNITY_Meter Reset Ops|Meter Reset Ops]]
- [[_COMMUNITY_Peak Meter|Peak Meter]]
- [[_COMMUNITY_RMS Meter|RMS Meter]]
- [[_COMMUNITY_Compressor|Compressor]]
- [[_COMMUNITY_Community 22|Community 22]]
- [[_COMMUNITY_Community 23|Community 23]]
- [[_COMMUNITY_Community 24|Community 24]]
- [[_COMMUNITY_Community 25|Community 25]]
- [[_COMMUNITY_Community 26|Community 26]]
- [[_COMMUNITY_Community 27|Community 27]]
- [[_COMMUNITY_Community 28|Community 28]]
- [[_COMMUNITY_Community 29|Community 29]]
- [[_COMMUNITY_Community 30|Community 30]]
- [[_COMMUNITY_Community 31|Community 31]]
- [[_COMMUNITY_Community 32|Community 32]]

## God Nodes (most connected - your core abstractions)
1. `AetherEditor` - 35 edges
2. `SharedState` - 28 edges
3. `LucentRelay` - 24 edges
4. `Biquad` - 24 edges
5. `Lucent` - 21 edges
6. `RelayHub` - 21 edges
7. `AetherParams` - 20 edges
8. `Aurum` - 20 edges
9. `EquilibriumEditor` - 20 edges
10. `Meridian` - 20 edges

## Surprising Connections (you probably didn't know these)
- `section_header()` --calls--> `bold_font()`  [INFERRED]
  plugins/aether/src/editor.rs → shared-ui/src/widgets.rs
- `Aurum` --references--> `ToleranceTable`  [EXTRACTED]
  plugins/aurum/src/lib.rs → shared-dsp/src/lib.rs
- `AetherEditor` --references--> `SharedState`  [EXTRACTED]
  plugins/aether/src/editor.rs → shared-analysis/src/lib.rs
- `AetherParams` --references--> `SharedState`  [EXTRACTED]
  plugins/aether/src/lib.rs → shared-analysis/src/lib.rs
- `Aether` --references--> `Biquad`  [EXTRACTED]
  plugins/aether/src/lib.rs → shared-dsp/src/lib.rs

## Import Cycles
- 1-file cycle: `shared-ui/src/canvas.rs -> shared-ui/src/canvas.rs`

## Communities (39 total, 7 thin omitted)

### Community 0 - "Lucent Relay Editor"
Cohesion: 0.05
Nodes (40): section_header(), RelayMsg, RelayUi, Arc, Element, IcedPlugin, Message, ParamCache (+32 more)

### Community 1 - "UI Widgets"
Cohesion: 0.10
Nodes (50): Action, Event, Font, Interaction, Point, RangeInclusive, at_block(), auto_loud_button() (+42 more)

### Community 2 - "Aether Editor"
Cohesion: 0.11
Nodes (30): AetherParamsParamId, AetherEditor, AetherMsg, AetherProfile, angle_from_ui(), default_presets(), eq_field_id(), harman_flat_profile() (+22 more)

### Community 3 - "Aurum Editor & Analysis"
Cohesion: 0.08
Nodes (34): AtomicF32, AtomicI32, AtomicU8, AurumParamsParamId, AurumEditor, AurumMsg, band_col(), Arc (+26 more)

### Community 4 - "Lucent Core"
Cohesion: 0.22
Nodes (7): panel_bg(), ParamCache, PluginContext, Task, resonance_hub(), ResonanceHub, Style

### Community 5 - "Canvas Visualizers"
Cohesion: 0.14
Nodes (29): Color, Length, balance_correlation_block(), BalanceCanvas, CorrelationCanvas, EqOverlay, GoniometerCanvas, output_level_block() (+21 more)

### Community 6 - "Shared Memory Hub"
Cohesion: 0.11
Nodes (16): AtomicU32, AtomicU64, Send, ConsumerSlot, display_name(), HubShared, PublisherSlot, RelayHub (+8 more)

### Community 7 - "Aurum Core"
Cohesion: 0.33
Nodes (4): HarmonicsMode, MasteringClipper, MasteringSaturator, ToleranceTable

### Community 8 - "Aether Core"
Cohesion: 0.04
Nodes (44): A) Existing repo + remote (fast path), AskUserQuestion Patterns, Automation Recipes, B) Not a repo yet, C) Configure GitHub remote using gh (optional), D) Configure remote manually (no gh), Git Sync, Preflight Checklist (+36 more)

### Community 9 - "Lucent Editor"
Cohesion: 0.09
Nodes (36): M, EqPreset, EqSpectrumCanvas, EquilibriumEditor, EquilibriumMsg, format_pan(), load_presets(), Arc (+28 more)

### Community 10 - "Vault & Config"
Cohesion: 0.18
Nodes (22): Error, HashMap, export_preset_to_markdown(), format_pan_str(), get_plugin_dir(), list_custom_presets(), load_config(), parse_frontmatter() (+14 more)

### Community 11 - "Filter Design"
Cohesion: 0.13
Nodes (5): BandLimiter, LR2Crossover, MsBandLimiter, Default, SweeteningEq

### Community 12 - "FFT Analysis"
Cohesion: 0.07
Nodes (22): db_to_gain(), Equilibrium, gain_to_db(), Arc, AudioBuffer, Box, Editor, EventList (+14 more)

### Community 13 - "Metering & Dynamics"
Cohesion: 0.07
Nodes (34): MeridianEditor, MeridianMsg, Arc, Element, IcedPlugin, Message, ParamCache, PluginContext (+26 more)

### Community 17 - "UI Panels"
Cohesion: 0.27
Nodes (10): Item, Iterator, ai_preset_panel(), preset_list_item(), Element, Fn, Message, Option (+2 more)

### Community 18 - "Meter Reset Ops"
Cohesion: 0.11
Nodes (18): Aether, AutoEqFilter, AutoEqProfile, parse_autoeq(), parses_autoeq(), Arc, AudioBuffer, Box (+10 more)

### Community 20 - "RMS Meter"
Cohesion: 0.09
Nodes (15): Aurum, Arc, AtomicBool, AudioBuffer, Box, Drop, Editor, EventList (+7 more)

### Community 22 - "Community 22"
Cohesion: 0.19
Nodes (11): LucentEditor, LucentMsg, Arc, Element, IcedPlugin, Message, Option, Self (+3 more)

### Community 23 - "Community 23"
Cohesion: 0.17
Nodes (9): MaskingAnalyzer, PeakTracker, AudioBuffer, EventList, Option, ProcessContext, ProcessStatus, Self (+1 more)

### Community 24 - "Community 24"
Cohesion: 0.15
Nodes (11): Lucent, Arc, AtomicBool, Box, Complex, Drop, Editor, PluginLogic (+3 more)

### Community 25 - "Community 25"
Cohesion: 0.24
Nodes (6): LucentUiState, RelayData, Default, Self, String, Vec

### Community 26 - "Community 26"
Cohesion: 0.20
Nodes (9): DSP Auditor — LX Audiolabs CLAP Plugin Development, DSP Safety, Dynamics, Filter Design, Output Format, Performance, Red Lines, Session Start (+1 more)

### Community 27 - "Community 27"
Cohesion: 0.25
Nodes (6): gain_to_db(), LucentParams, LucentState, IntParam, String, RwLock

### Community 28 - "Community 28"
Cohesion: 0.25
Nodes (7): After every write, File paths, Frontmatter (mandatory on every note), Red Lines (NEVER TOUCH), Session Start (MANDATORY — 30 seconds), Vault Keeper — LX Audiolabs CLAP Plugin Development, Write Rules

### Community 30 - "Community 30"
Cohesion: 0.50
Nodes (3): EXECUTION CONTRACT, graphify, LX Audiolabs — Claude Code Bootstrap

### Community 31 - "Community 31"
Cohesion: 0.50
Nodes (3): Copilot Instructions — Caveman Mode, graphify, Ponytail — Lazy Senior Dev Mode

## Knowledge Gaps
- **55 isolated node(s):** `Session Start`, `Filter Design`, `Dynamics`, `DSP Safety`, `Performance` (+50 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **7 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `SharedState` connect `Aurum Editor & Analysis` to `Lucent Relay Editor`, `Aether Editor`, `Lucent Editor`, `Metering & Dynamics`, `Meter Reset Ops`, `RMS Meter`, `Community 22`, `Community 27`?**
  _High betweenness centrality (0.348) - this node is a cross-community bridge._
- **Why does `Biquad` connect `DSP Constructors` to `Aurum Core`, `Filter Design`, `FFT Analysis`, `Metering & Dynamics`, `Lucent UI State`, `Meter Reset Ops`, `RMS Meter`, `Compressor`?**
  _High betweenness centrality (0.098) - this node is a cross-community bridge._
- **Why does `EquilibriumParams` connect `Lucent Editor` to `Aurum Editor & Analysis`, `FFT Analysis`?**
  _High betweenness centrality (0.095) - this node is a cross-community bridge._
- **What connects `Session Start`, `Filter Design`, `Dynamics` to the rest of the system?**
  _55 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `Lucent Relay Editor` be split into smaller, more focused modules?**
  _Cohesion score 0.05017921146953405 - nodes in this community are weakly interconnected._
- **Should `UI Widgets` be split into smaller, more focused modules?**
  _Cohesion score 0.1016949152542373 - nodes in this community are weakly interconnected._
- **Should `Aether Editor` be split into smaller, more focused modules?**
  _Cohesion score 0.10714285714285714 - nodes in this community are weakly interconnected._