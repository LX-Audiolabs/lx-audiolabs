# Graph Report - lx-audiolabs-dev  (2026-07-02)

## Corpus Check
- 69 files · ~98,550 words
- Verdict: corpus is large enough that graph structure adds value.

## Summary
- 1478 nodes · 2877 edges · 94 communities (65 shown, 29 thin omitted)
- Extraction: 98% EXTRACTED · 2% INFERRED · 0% AMBIGUOUS · INFERRED: 44 edges (avg confidence: 0.8)
- Token cost: 0 input · 0 output

## Graph Freshness
- Built from commit: `4efaf76e`
- Run `git rev-parse HEAD` and compare to check if the graph is stale.
- Run `graphify update .` after code changes (no API cost).

## Community Hubs (Navigation)
- [[_COMMUNITY_Panel UI Components|Panel UI Components]]
- [[_COMMUNITY_Equilibrium Editor UI|Equilibrium Editor UI]]
- [[_COMMUNITY_Parameter Cache UI|Parameter Cache UI]]
- [[_COMMUNITY_Lucent Editor UI|Lucent Editor UI]]
- [[_COMMUNITY_Generic Types and Traits|Generic Types and Traits]]
- [[_COMMUNITY_Lucent Relay UI|Lucent Relay UI]]
- [[_COMMUNITY_iOS Editor Integration|iOS Editor Integration]]
- [[_COMMUNITY_Meridian Editor UI|Meridian Editor UI]]
- [[_COMMUNITY_Aether Editor EQ|Aether Editor EQ]]
- [[_COMMUNITY_Iced Editor Framework|Iced Editor Framework]]
- [[_COMMUNITY_Meridian DSP Processing|Meridian DSP Processing]]
- [[_COMMUNITY_XY Pad Widget|XY Pad Widget]]
- [[_COMMUNITY_Audio Canvas Widgets|Audio Canvas Widgets]]
- [[_COMMUNITY_Knob Widget|Knob Widget]]
- [[_COMMUNITY_Slider Widget|Slider Widget]]
- [[_COMMUNITY_Meter Widget|Meter Widget]]
- [[_COMMUNITY_Font and Keyboard Handling|Font and Keyboard Handling]]
- [[_COMMUNITY_Relay Hub System|Relay Hub System]]
- [[_COMMUNITY_Aether DSP Core|Aether DSP Core]]
- [[_COMMUNITY_Plugin and Tool List|Plugin and Tool List]]
- [[_COMMUNITY_Preset Management and Config|Preset Management and Config]]
- [[_COMMUNITY_Aurum Editor UI|Aurum Editor UI]]
- [[_COMMUNITY_Aurum DSP Core|Aurum DSP Core]]
- [[_COMMUNITY_Band Limiter and Crossover|Band Limiter and Crossover]]
- [[_COMMUNITY_Biquad Filter Implementation|Biquad Filter Implementation]]
- [[_COMMUNITY_Spectrum Analysis State|Spectrum Analysis State]]
- [[_COMMUNITY_Lucent Relay State|Lucent Relay State]]
- [[_COMMUNITY_RMS Meter|RMS Meter]]
- [[_COMMUNITY_Loudness Meter|Loudness Meter]]
- [[_COMMUNITY_Aurum Parameter Handling|Aurum Parameter Handling]]
- [[_COMMUNITY_Library Documentation and Bugs|Library Documentation and Bugs]]
- [[_COMMUNITY_Screenshot and State Test|Screenshot and State Test]]
- [[_COMMUNITY_WGPU Surface Creation|WGPU Surface Creation]]
- [[_COMMUNITY_Audio Compressor|Audio Compressor]]
- [[_COMMUNITY_Mastering ClipperSaturator|Mastering Clipper/Saturator]]
- [[_COMMUNITY_Obsidian and Git Resources|Obsidian and Git Resources]]
- [[_COMMUNITY_Peak Meter|Peak Meter]]
- [[_COMMUNITY_Mid-Side EQ|Mid-Side EQ]]
- [[_COMMUNITY_Tolerance Table|Tolerance Table]]
- [[_COMMUNITY_CI Build Pipeline|CI Build Pipeline]]
- [[_COMMUNITY_Community 47|Community 47]]
- [[_COMMUNITY_Community 48|Community 48]]
- [[_COMMUNITY_Community 49|Community 49]]
- [[_COMMUNITY_Community 50|Community 50]]
- [[_COMMUNITY_Community 51|Community 51]]
- [[_COMMUNITY_Community 52|Community 52]]
- [[_COMMUNITY_Community 53|Community 53]]
- [[_COMMUNITY_Community 54|Community 54]]
- [[_COMMUNITY_Community 55|Community 55]]
- [[_COMMUNITY_Community 56|Community 56]]
- [[_COMMUNITY_Community 57|Community 57]]
- [[_COMMUNITY_Community 58|Community 58]]
- [[_COMMUNITY_Community 59|Community 59]]
- [[_COMMUNITY_Community 60|Community 60]]
- [[_COMMUNITY_Community 61|Community 61]]
- [[_COMMUNITY_Community 62|Community 62]]
- [[_COMMUNITY_Community 63|Community 63]]
- [[_COMMUNITY_Community 64|Community 64]]
- [[_COMMUNITY_Community 65|Community 65]]
- [[_COMMUNITY_Community 66|Community 66]]
- [[_COMMUNITY_Community 67|Community 67]]
- [[_COMMUNITY_Community 68|Community 68]]
- [[_COMMUNITY_Community 69|Community 69]]
- [[_COMMUNITY_Community 70|Community 70]]
- [[_COMMUNITY_Community 71|Community 71]]
- [[_COMMUNITY_Community 72|Community 72]]
- [[_COMMUNITY_Community 73|Community 73]]
- [[_COMMUNITY_Community 74|Community 74]]
- [[_COMMUNITY_Community 75|Community 75]]
- [[_COMMUNITY_Community 76|Community 76]]
- [[_COMMUNITY_Community 77|Community 77]]
- [[_COMMUNITY_Community 78|Community 78]]
- [[_COMMUNITY_Community 79|Community 79]]
- [[_COMMUNITY_Community 80|Community 80]]
- [[_COMMUNITY_Community 81|Community 81]]
- [[_COMMUNITY_Community 82|Community 82]]
- [[_COMMUNITY_Community 83|Community 83]]
- [[_COMMUNITY_Community 84|Community 84]]
- [[_COMMUNITY_Community 85|Community 85]]
- [[_COMMUNITY_Community 86|Community 86]]
- [[_COMMUNITY_Community 87|Community 87]]
- [[_COMMUNITY_Community 88|Community 88]]
- [[_COMMUNITY_Community 89|Community 89]]
- [[_COMMUNITY_Community 90|Community 90]]
- [[_COMMUNITY_Community 91|Community 91]]
- [[_COMMUNITY_Community 92|Community 92]]
- [[_COMMUNITY_Community 93|Community 93]]

## God Nodes (most connected - your core abstractions)
1. `Message` - 92 edges
2. `ParamCache` - 44 edges
3. `AetherEditor` - 35 edges
4. `SharedState` - 28 edges
5. `LucentRelay` - 24 edges
6. `MeridianEditor` - 23 edges
7. `Biquad` - 23 edges
8. `Lucent` - 22 edges
9. `ClapPluginData` - 22 edges
10. `IcedEditor<P, M>` - 22 edges

## Surprising Connections (you probably didn't know these)
- `section_header()` --calls--> `bold_font()`  [INFERRED]
  plugins/aether/src/editor.rs → shared-ui/src/widgets.rs
- `Aurum` --references--> `ToleranceTable`  [EXTRACTED]
  plugins/aurum/src/lib.rs → shared-dsp/src/lib.rs
- `AetherEditor` --references--> `SharedState`  [EXTRACTED]
  plugins/aether/src/editor.rs → shared-analysis/src/lib.rs
- `AetherEditor` --implements--> `IcedPlugin`  [EXTRACTED]
  plugins/aether/src/editor.rs → truce-iced-local/src/runtime.rs
- `AetherParams` --references--> `SharedState`  [EXTRACTED]
  plugins/aether/src/lib.rs → shared-analysis/src/lib.rs

## Import Cycles
- 1-file cycle: `shared-ui/src/canvas.rs -> shared-ui/src/canvas.rs`
- 1-file cycle: `truce-clap-local/src/presets.rs -> truce-clap-local/src/presets.rs`
- 1-file cycle: `truce-iced-local/src/keyboard.rs -> truce-iced-local/src/keyboard.rs`
- 1-file cycle: `truce-iced-local/src/platform.rs -> truce-iced-local/src/platform.rs`

## Hyperedges (group relationships)
- **LX Audiolabs CLAP Plugins** — concept_aether, concept_aurum, concept_equilibrium, concept_lucent, concept_meridian [EXTRACTED 1.00]
- **CI Build Workflows** — github_workflows_build_aether_yml, github_workflows_build_aurum_yml, github_workflows_build_equilibrium_yml, github_workflows_build_lucent_yml, github_workflows_build_meridian_yml, github_workflows_build_all_yml [EXTRACTED 1.00]
- **Agent and Skill Resources for Vault/Obsidian** — claude_agents_dsp_auditor_md, claude_agents_vault_keeper_md, claude_skills_obsidian_skill_md, claude_skills_obsidian_resources_git_sync_md, claude_skills_obsidian_resources_obsidian_conventions_md, claude_skills_obsidian_resources_tool_patterns_md [INFERRED 0.90]

## Communities (94 total, 29 thin omitted)

### Community 0 - "Panel UI Components"
Cohesion: 0.20
Nodes (31): Element, RangeInclusive, at_block(), auto_loud_button(), bold_font(), change_only(), Gesture, header_brand() (+23 more)

### Community 1 - "Equilibrium Editor UI"
Cohesion: 0.13
Nodes (15): db_to_gain(), Equilibrium, gain_to_db(), Arc, AudioBuffer, Box, Editor, EventList (+7 more)

### Community 2 - "Parameter Cache UI"
Cohesion: 0.05
Nodes (48): Copy, Q, ParamCache, ParamCache<P>, Arc, Font, HashMap, Into (+40 more)

### Community 3 - "Lucent Editor UI"
Cohesion: 0.05
Nodes (43): LucentEditor, LucentMsg, panel_bg(), Arc, Element, Option, PluginContext, Self (+35 more)

### Community 4 - "Generic Types and Traits"
Cohesion: 0.05
Nodes (47): Any, Backends, Cache, Device, Id, Sized, SubRuntime, SurfaceConfiguration (+39 more)

### Community 5 - "Lucent Relay UI"
Cohesion: 0.05
Nodes (39): params_key(), RelayMsg, RelayUi, Arc, Element, Option, PluginContext, Self (+31 more)

### Community 6 - "iOS Editor Integration"
Cohesion: 0.08
Nodes (42): AnyClass, AnyObject, Bool, FnOnce, InnerSlot, Sel, TouchPhase, borrow_inner_arc() (+34 more)

### Community 7 - "Meridian Editor UI"
Cohesion: 0.09
Nodes (42): apply_profile(), CompressorEnvelopeCanvas, compute_eq_curve(), export_meridian_markdown(), inflate_roundtrips_through_markdown(), list_meridian_presets(), MeridianEditor, MeridianMsg (+34 more)

### Community 8 - "Aether Editor EQ"
Cohesion: 0.11
Nodes (29): AetherParamsParamId, AetherEditor, AetherMsg, AetherProfile, angle_from_ui(), default_presets(), eq_field_id(), harman_flat_profile() (+21 more)

### Community 9 - "Iced Editor Framework"
Cohesion: 0.06
Nodes (31): EventStatus, MouseCursor, iced_interaction_to_cursor(), IcedBaseviewHandler, IcedBaseviewHandler<P, M>, IcedEditor, IcedEditor<P, AutoPlugin>, IcedEditor<P, M> (+23 more)

### Community 10 - "Meridian DSP Processing"
Cohesion: 0.06
Nodes (31): db_to_gain(), gain_to_db(), inflate_shape(), Meridian, Arc, AudioBuffer, Box, Complex (+23 more)

### Community 11 - "XY Pad Widget"
Cohesion: 0.09
Nodes (27): Element<'a, Message<M>>, Action, Cursor, Element, Event, Font, From, Geometry (+19 more)

### Community 12 - "Audio Canvas Widgets"
Cohesion: 0.16
Nodes (24): BalanceCanvas, CorrelationCanvas, EqOverlay, GoniometerCanvas, OutputPeakCanvas, Arc, Color, Cursor (+16 more)

### Community 13 - "Knob Widget"
Cohesion: 0.17
Nodes (13): KnobProgram, Action, Cursor, Event, Geometry, Interaction, Option, Program (+5 more)

### Community 14 - "Slider Widget"
Cohesion: 0.10
Nodes (26): Element<'a, Message<M>>, Action, Cursor, Element, Event, Font, From, Geometry (+18 more)

### Community 15 - "Meter Widget"
Cohesion: 0.11
Nodes (23): Element<'a, Message<M>>, MeterProgram, MeterWidget, MeterWidget<'a, M>, Action, Cursor, Element, Event (+15 more)

### Community 16 - "Font and Keyboard Handling"
Cohesion: 0.19
Nodes (19): Code, KeyboardEvent, KeyState, Location, Modifiers, Physical, character_down_carries_text_and_physical_code(), convert_code() (+11 more)

### Community 17 - "Relay Hub System"
Cohesion: 0.12
Nodes (16): ConsumerSlot, display_name(), HubShared, PublisherSlot, RelayHub, AtomicU32, AtomicU64, Option (+8 more)

### Community 18 - "Aether DSP Core"
Cohesion: 0.11
Nodes (18): Aether, AutoEqFilter, AutoEqProfile, parse_autoeq(), parses_autoeq(), Arc, AudioBuffer, Box (+10 more)

### Community 19 - "Plugin and Tool List"
Cohesion: 0.13
Nodes (15): Aether Plugin, Aurum Plugin, cargo-truce Build Tool, Equilibrium Plugin, Lucent Plugin, Meridian Plugin, Build Aether Workflow, Build All Plugins Workflow (+7 more)

### Community 20 - "Preset Management and Config"
Cohesion: 0.18
Nodes (22): Error, export_preset_to_markdown(), format_pan_str(), get_plugin_dir(), list_custom_presets(), load_config(), parse_frontmatter(), parse_frontmatter_list() (+14 more)

### Community 21 - "Aurum Editor UI"
Cohesion: 0.13
Nodes (18): AurumParamsParamId, AurumEditor, AurumMsg, band_col(), Arc, Element, Fn, Option (+10 more)

### Community 22 - "Aurum DSP Core"
Cohesion: 0.09
Nodes (15): Aurum, Arc, AtomicBool, AudioBuffer, Box, Drop, Editor, EventList (+7 more)

### Community 23 - "Band Limiter and Crossover"
Cohesion: 0.13
Nodes (5): BandLimiter, LR2Crossover, MsBandLimiter, MsEq, Default

### Community 25 - "Spectrum Analysis State"
Cohesion: 0.14
Nodes (13): AtomicF32, AtomicI32, AtomicU8, compute_spectrum_bins(), Arc, AtomicBool, AtomicUsize, Complex (+5 more)

### Community 26 - "Lucent Relay State"
Cohesion: 0.24
Nodes (6): LucentUiState, RelayData, Default, Self, String, Vec

### Community 27 - "RMS Meter"
Cohesion: 0.17
Nodes (3): PeakMeter, Self, ToleranceTable<N>

### Community 28 - "Loudness Meter"
Cohesion: 0.16
Nodes (6): EbuR128, AutoLoudMeter, HarmonicsMode, MasteringClipper, MasteringSaturator, ToleranceTable

### Community 29 - "Aurum Parameter Handling"
Cohesion: 0.04
Nodes (44): A) Existing repo + remote (fast path), AskUserQuestion Patterns, Automation Recipes, B) Not a repo yet, C) Configure GitHub remote using gh (optional), D) Configure remote manually (no gh), Git Sync, Preflight Checklist (+36 more)

### Community 31 - "Screenshot and State Test"
Cohesion: 0.10
Nodes (33): clap_gui_resize_hints, clap_ostream, clap_plugin, clap_window, audio_ports_count(), clap_plugin_activate(), clap_plugin_deactivate(), clap_plugin_destroy() (+25 more)

### Community 32 - "WGPU Surface Creation"
Cohesion: 0.36
Nodes (7): NonZeroIsize, create_wgpu_surface(), current_module_hinstance(), Instance, Option, Surface, Window

### Community 34 - "Mastering Clipper/Saturator"
Cohesion: 0.10
Nodes (32): clap_preset_discovery_factory, clap_preset_discovery_indexer, clap_preset_discovery_location, clap_preset_discovery_metadata_receiver, clap_preset_discovery_provider, clap_preset_discovery_provider_descriptor, PresetRef, declare_dir() (+24 more)

### Community 36 - "Peak Meter"
Cohesion: 0.19
Nodes (18): HSliderProgram<'a, Message>, HSliderState, KnobProgram<'a, Message>, KnobState, Action, Cursor, Event, Geometry (+10 more)

### Community 37 - "Mid-Side EQ"
Cohesion: 0.11
Nodes (22): clap_host_params, clap_input_events, clap_output_events, GuiChangeQueue, ParamInfo, Sample, StateLoadQueue, TransportSlot (+14 more)

### Community 38 - "Tolerance Table"
Cohesion: 0.12
Nodes (16): clap_plugin_audio_ports, clap_plugin_gui, clap_plugin_latency, clap_plugin_note_ports, clap_plugin_params, clap_plugin_preset_load, clap_plugin_state, clap_plugin_tail (+8 more)

### Community 47 - "Community 47"
Cohesion: 0.28
Nodes (11): EqPreset, EquilibriumEditor, format_pan(), load_presets(), Arc, Option, PathBuf, Self (+3 more)

### Community 48 - "Community 48"
Cohesion: 0.21
Nodes (10): EquilibriumMsg, BoolParam, FloatParam, Fn, PluginContext, Subscription, Task, EquilibriumParams (+2 more)

### Community 49 - "Community 49"
Cohesion: 0.23
Nodes (10): clap_istream, PluginInfo, anchor_child_to_top(), clap_plugin_get_extension(), Extensions<P>, gui_set_parent_inner(), resolved_name(), c_void (+2 more)

### Community 50 - "Community 50"
Cohesion: 0.18
Nodes (12): clap_id, DescriptorHolder, params_text_to_value(), params_value_to_text(), preset_load_from_location(), c_char, clap_preset_discovery_location_kind, CStr (+4 more)

### Community 51 - "Community 51"
Cohesion: 0.17
Nodes (11): EqSpectrumCanvas, Cursor, Geometry, M, Program, Rectangle, Renderer, State (+3 more)

### Community 52 - "Community 52"
Cohesion: 0.27
Nodes (8): Element<'a, Message<M>>, KnobState, KnobWidget, Element, From, M, PhantomData, Theme

### Community 53 - "Community 53"
Cohesion: 0.20
Nodes (9): DSP Auditor — LX Audiolabs CLAP Plugin Development, DSP Safety, Dynamics, Filter Design, Output Format, Performance, Red Lines, Session Start (+1 more)

### Community 54 - "Community 54"
Cohesion: 0.31
Nodes (9): Item, Iterator, ai_preset_panel(), preset_list_item(), Element, Fn, Option, String (+1 more)

### Community 55 - "Community 55"
Cohesion: 0.36
Nodes (5): KnobWidget<'a, M>, Font, Into, Params, Self

### Community 56 - "Community 56"
Cohesion: 0.22
Nodes (8): Expected behaviour, Fix, OS and rust version, Plugin format, Root Cause, Steps to reproduce, What happened?, Workspace version

### Community 57 - "Community 57"
Cohesion: 0.29
Nodes (8): clap_host, clap_plugin_descriptor, create_plugin_instance(), gui_adjust_size(), gui_set_size(), request_host_resize(), scale_logical_to_physical(), scale_physical_to_logical()

### Community 58 - "Community 58"
Cohesion: 0.25
Nodes (7): After every write, File paths, Frontmatter (mandatory on every note), Red Lines (NEVER TOUCH), Session Start (MANDATORY — 30 seconds), Vault Keeper — LX Audiolabs CLAP Plugin Development, Write Rules

### Community 59 - "Community 59"
Cohesion: 0.29
Nodes (7): clap_audio_port_info, clap_note_port_info, clap_param_info, audio_ports_get(), copy_str_to_buf(), note_ports_get(), params_get_info()

### Community 60 - "Community 60"
Cohesion: 0.33
Nodes (5): apply_font(), extract_family_name(), Font, Option, String

### Community 61 - "Community 61"
Cohesion: 0.33
Nodes (6): render_to_pixels(), Arc, M, Option, P, Vec

### Community 62 - "Community 62"
Cohesion: 0.33
Nodes (6): clap_event_transport, clap_process, TransportInfo, build_transport_info(), clap_plugin_process(), position_samples_derived_from_seconds_timeline()

### Community 64 - "Community 64"
Cohesion: 0.33
Nodes (5): auto_view(), Element, GridLayout, M, P

### Community 65 - "Community 65"
Cohesion: 0.40
Nodes (4): Key macro, Overview, truce-clap, What it handles

### Community 66 - "Community 66"
Cohesion: 0.40
Nodes (4): Key types, Overview, truce-iced, Usage

### Community 67 - "Community 67"
Cohesion: 0.50
Nodes (3): EXECUTION CONTRACT, graphify, LX Audiolabs — Claude Code Bootstrap

### Community 68 - "Community 68"
Cohesion: 0.50
Nodes (3): Copilot Instructions — Caveman Mode, graphify, Ponytail — Lazy Senior Dev Mode

### Community 70 - "Community 70"
Cohesion: 0.50
Nodes (4): balance_correlation_block(), output_level_block(), Element, Length

### Community 71 - "Community 71"
Cohesion: 0.67
Nodes (3): knob_arc(), Path, Point

## Knowledge Gaps
- **92 isolated node(s):** `GuiParamChange`, `IcedEditor<P, AutoPlugin>`, `IcedEditor<P, AutoPlugin>`, `KnobState`, `SliderState` (+87 more)
  These have ≤1 connection - possible missing edges or undocumented components.
- **29 thin communities (<3 nodes) omitted from report** — run `graphify query` to explore isolated nodes.

## Suggested Questions
_Questions this graph is uniquely positioned to answer:_

- **Why does `Message` connect `Panel UI Components` to `Community 64`, `Parameter Cache UI`, `Lucent Editor UI`, `Peak Meter`, `Lucent Relay UI`, `Community 70`, `Meridian Editor UI`, `Aether Editor EQ`, `Generic Types and Traits`, `XY Pad Widget`, `Audio Canvas Widgets`, `Knob Widget`, `Slider Widget`, `Meter Widget`, `Community 48`, `Community 52`, `Aurum Editor UI`, `Community 54`?**
  _High betweenness centrality (0.285) - this node is a cross-community bridge._
- **Why does `IcedRuntime` connect `Generic Types and Traits` to `Panel UI Components`, `Iced Editor Framework`, `iOS Editor Integration`?**
  _High betweenness centrality (0.163) - this node is a cross-community bridge._
- **Why does `SharedState` connect `Spectrum Analysis State` to `Lucent Editor UI`, `Lucent Relay UI`, `Meridian Editor UI`, `Aether Editor EQ`, `Community 47`, `Community 48`, `Aether DSP Core`, `Aurum Editor UI`, `Aurum DSP Core`?**
  _High betweenness centrality (0.111) - this node is a cross-community bridge._
- **What connects `GuiParamChange`, `IcedEditor<P, AutoPlugin>`, `IcedEditor<P, AutoPlugin>` to the rest of the system?**
  _92 weakly-connected nodes found - possible documentation gaps or missing edges._
- **Should `Equilibrium Editor UI` be split into smaller, more focused modules?**
  _Cohesion score 0.12648221343873517 - nodes in this community are weakly interconnected._
- **Should `Parameter Cache UI` be split into smaller, more focused modules?**
  _Cohesion score 0.053923541247484906 - nodes in this community are weakly interconnected._
- **Should `Lucent Editor UI` be split into smaller, more focused modules?**
  _Cohesion score 0.05179982440737489 - nodes in this community are weakly interconnected._